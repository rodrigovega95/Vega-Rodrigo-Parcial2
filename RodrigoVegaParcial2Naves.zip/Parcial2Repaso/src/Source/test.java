/* Definición de una interfaz */
public interface NombreInterfaz {
    // Métodos abstractos
    void metodo1(); // Método que debe ser implementado por cualquier clase que use esta interfaz
    int metodo2(String parametro); // Método que devuelve un entero basado en un parámetro String
}

/* Implementación de una interfaz */
public class ClaseEjemplo implements NombreInterfaz {
    @Override
    public void metodo1() {
        // Implementación del método definido en la interfaz
        System.out.println("Implementación del método 1");
    }

    @Override
    public int metodo2(String parametro) {
        // Implementación que devuelve la longitud del parámetro String
        return parametro.length();
    }
}

/* Uso de genéricos */

// Sin genéricos
List lista = new ArrayList();
lista.add("Cadena");
String elemento = (String) lista.get(0); // Conversión explícita necesaria

// Con genéricos
List<String> lista = new ArrayList<>();
lista.add("Cadena");
String elemento = lista.get(0); // Conversión explícita no necesaria

/* Clase genérica */

// Clase sin genéricos
public class Box {
    private Object objeto;

    public void set(Object objeto) {
        // Método para establecer un objeto
        this.objeto = objeto;
    }

    public Object get() {
        // Método para obtener el objeto
        return objeto;
    }
}

// Clase genérica
public class Box<T> {
    private T objeto;

    public void set(T objeto) {
        // Método para establecer un objeto del tipo genérico T
        this.objeto = objeto;
    }

    public T get() {
        // Método para obtener el objeto del tipo genérico T
        return objeto;
    }
}

// Ejemplo de uso de una clase genérica
Box<Integer> caja = new Box<>();
caja.set(10); // Establece un valor entero en la caja
Integer numero = caja.get(); // Recupera el valor entero

/* Expresiones lambda */

// Implementación de un Predicate para validar cadenas de longitud 3
Predicate<String> longitudTres = s -> s.length() == 3;
boolean resultado = longitudTres.test("abc"); // Devuelve true si la longitud es 3

// Implementación de un Consumer para imprimir una cadena
Consumer<String> imprimir = s -> System.out.println(s);
imprimir.accept("Hola, mundo"); // Imprime "Hola, mundo"

// Implementación de un Runnable para ejecutar una acción
Runnable ejecutable = () -> System.out.println("Ejecutando...");
new Thread(ejecutable).start(); // Crea y ejecuta un hilo

/* Lectura de archivos */
File archivo = new File("ruta/al/archivo.txt");
try (BufferedReader lector = new BufferedReader(new FileReader(archivo))) {
    String linea;
    while ((linea = lector.readLine()) != null) {
        // Imprime cada línea del archivo
        System.out.println(linea);
    }
} catch (IOException e) {
    e.printStackTrace(); // Maneja excepciones de entrada/salida
}

/* Escritura en archivos */
File archivo = new File("ruta/al/archivo.txt");
try (BufferedWriter escritor = new BufferedWriter(new FileWriter(archivo))) {
    escritor.write("Hola, mundo"); // Escribe texto en el archivo
    escritor.newLine(); // Añade un salto de línea
    escritor.write("Otra línea de texto"); // Escribe otra línea
} catch (IOException e) {
    e.printStackTrace(); // Maneja excepciones de entrada/salida
}

/* Serialización y deserialización */

// Serialización: Guardar un objeto en un archivo
try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream("objeto.ser"))) {
    salida.writeObject(objetoSerializable); // Serializa el objeto
} catch (IOException e) {
    e.printStackTrace(); // Maneja excepciones de entrada/salida
}

// Deserialización: Leer un objeto desde un archivo
try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream("objeto.ser"))) {
    MiClase objeto = (MiClase) entrada.readObject(); // Recupera el objeto serializado
} catch (IOException | ClassNotFoundException e) {
    e.printStackTrace(); // Maneja excepciones de entrada/salida y clase no encontrada
}
